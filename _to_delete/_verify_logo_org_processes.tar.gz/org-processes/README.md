# Qorix Engineering Processes

## One organization, one repo, one workspace

Everything — docs, product traceability, governance, and source for five
languages — lives in this single repository, opened in VS Code as a single
workspace root via `qorix-engg.code-workspace` (no multi-root, no separate
repos to juggle).

# Org Processes

Organization-wide processes and standards repository.

## Areas

- Governance
- Strategy
- Infrastructure
- Testing
- Learning Management
- Tools
- Common Framework

```
test_repo/
├── .github/
│   └── workflows/
│       ├── ci-needs.yml
│       ├── ci.yml
│       └── docs.yml
├── .vscode/
│   ├── extensions.json
│   ├── settings.json
│   └── tasks.json
├── organisation/common_framework/
│   ├── core lib/   (empty)
│   └── HAL/   (empty)
├── organisation/governance/
│   ├── aspice/
│   │   ├── index.rst
│   │   └── org_aspice_requirements.rst
│   ├── coding guidelines/
│   │   ├── c/
│   │   │   ├── c_MISRA2017.md
│   │   │   └── README.md
│   │   ├── cpp/
│   │   │   └── README.md
│   │   ├── markdown/
│   │   │   └── README.md
│   │   ├── python/
│   │   │   └── README.md
│   │   └── rust/
│   │       ├── crates/
│   │       │   └── example_crate/
│   │       │       ├── src/
│   │       │       │   └── lib.rs
│   │       │       └── Cargo.toml
│   │       ├── Cargo.toml
│   │       ├── README.md
│   │       └── rustfmt.toml
│   ├── cybersecurity/
│   │   ├── index.rst
│   │   └── org_cybsec_requirements.rst
│   ├── functionalsafety/
│   │   ├── index.rst
│   │   └── org_fusa_requirements.rst
│   ├── policies/
│   │   ├── cybersecurity.rst
│   │   ├── quality.rst
│   │   └── safety.rst
│   └── index.rst
├── organisation/strategy/
│   ├── roadmap.rst
│   └── strategy.rst
├── organisation/tools/
│   ├── index.rst
│   ├── policy.rst
│   └── tool_qualification_requirements.rst
├── organisation/verification/
│   └── iso29119/
│       ├── policy/   (empty)
│       ├── strategy/
│       │   └── product-verification-strategy.rst
│       ├── index.rst
│       └── organizational_requirements.rst
