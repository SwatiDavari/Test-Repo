Common Framework
====================

Shared, cross-product implementation guidance — narrative documentation
for library code and platform capabilities reused across modules, as
distinct from ``Needs/`` (product-specific traceability) and
``organisation/governance/`` (organizational requirements and policy).

.. toctree::

   core lib/error_handling/index

``HAL/`` is scaffolded — no content yet.
