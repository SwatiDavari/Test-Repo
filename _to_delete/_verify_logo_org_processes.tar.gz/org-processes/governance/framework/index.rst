Enterprise Framework
========================

The organization's process definition: two committed, versioned diagrams
(replacing external whiteboard sketches with git-tracked source that
renders as part of this build, so every future change to either is a
reviewable diff, not a redrawn image), the lifecycle model those diagrams
describe, and the templates their "Guidance" elements refer to.

**2026-08-21: converted to a real toctree** (was prose links — see
``governance/index.rst``'s note on the same, now-obsolete Furo
workaround).

.. toctree::

   architecture
   process_metamodel
   lifecycle_model
   templates/index
