Organizational Governance
=============================

Organization-level requirements and policies — prerequisites that must
exist before any product-level work (safety, cybersecurity, quality) can
be considered valid under the corresponding standard. Per-standard detail
requirements live one folder down; policy statements (the "why", not the
detailed "shall" requirements) live under ``policies/``.

**2026-08-21: converted to a real toctree.** The Furo-era flattening
workaround (below, kept for history) no longer applies once a consuming
project uses a theme whose sidebar respects toctree nesting instead of
always rendering full depth. ``coding guidelines/`` isn't included below
-- it's plain Markdown (``.md``), and this project's own build has no
Markdown parser registered, so those files can't go in an RST toctree
without a bigger change (adding ``myst_parser`` or similar) that wasn't
part of this request.

.. toctree::
   :caption: Safety

   functionalsafety/index

.. toctree::
   :caption: Security

   cybersecurity/index

.. toctree::
   :caption: Quality

   quality/index

.. toctree::
   :caption: ASPICE

   aspice/index

.. toctree::
   :caption: System Lifecycle

   systemslifecycle/index

.. toctree::
   :caption: Framework

   framework/index

.. toctree::
   :caption: Policies

   policies/index

*Original note, no longer the current setup (kept for history)*: all of
the pages above used to be listed directly, flat, in the root sidebar's
"Organizational Governance" section rather than nested under this page.
Furo (this project's theme at the time) always rendered its sidebar at
full depth regardless of any toctree's ``:maxdepth:`` -- the only way to
avoid multi-level expandable nesting in the sidebar was to not declare
that nesting in a toctree at all, so each page linked to its children in
prose instead.
