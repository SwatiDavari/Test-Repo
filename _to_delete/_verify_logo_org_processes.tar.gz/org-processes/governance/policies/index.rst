Policy Statements
=====================

Organization-level policy statements — the "why" behind each domain's
detailed "shall" requirements, which live one folder up under
``functionalsafety/``, ``cybersecurity/``, and ``quality/`` respectively.
There is no separate ASPICE-specific or system-lifecycle-specific policy
file; those domains' requirements documents stand on their own.

This index did not exist before 2026-08-21 — these three pages had no
toctree parent anywhere in the project (referenced only in prose from
``governance/index.rst`` and one cross-reference from
``systemslifecycle/org_project_enabling_requirements.rst``).

.. toctree::

   safety
   quality
   cybersecurity
