Organization
================

Single landing page for all organization-level (as opposed to
product-specific) content, unifying what used to be three separate
top-level sidebar entries in the consuming project (test_repo):
governance, strategy, and common framework. Added 2026-08-21 in response
to a request to collapse those into one "Organization" entry with
everything else nested underneath as collapsible sub-menus.

See :doc:`known_gaps` for divergences between this structure and the
original sketch.

.. toctree::
   :caption: Governance & Compliance
   :maxdepth: 1

   governance/index

.. toctree::
   :caption: Infrastructure
   :maxdepth: 1

   infrastructure/index

.. toctree::
   :caption: Learning Management
   :maxdepth: 1

   learning_management/index

.. toctree::
   :caption: Testing
   :maxdepth: 1

   testing/index

.. toctree::
   :caption: Tool Governance
   :maxdepth: 1

   tools/index

.. toctree::
   :caption: Common Framework
   :maxdepth: 1

   common_framework/index

.. toctree::
   :caption: Enterprise Strategy
   :maxdepth: 1

   strategy/index

.. toctree::
   :hidden:

   known_gaps
