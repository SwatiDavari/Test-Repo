Infrastructure
==================

**Placeholder — no content yet.** This folder exists as a scaffold (per
``scripts/sync_org_content.sh`` in test_repo, which already syncs it) but
currently holds no ``.rst`` files. Added 2026-08-21 only so
"Infrastructure" has a landing page and shows up as a real, working
sidebar entry rather than a broken link, while the folder is empty.

Note: ``governance/systemslifecycle/infra_register`` already covers
organization-level infrastructure *requirements* (ISO 15288 6.2
project-enabling processes) — this page is reserved for infrastructure
documentation of a different kind (runbooks, environment inventories,
etc.), not yet written.
