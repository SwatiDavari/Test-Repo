Known Gaps
=============

Divergences between this "Organization" structure and the original
hand-drawn sketch it was built from, disclosed rather than hidden. Split
out of ``index.rst`` on 2026-08-21 so that page stays short.

- ``infrastructure/`` and ``learning_management/`` are empty folders
  with no real content yet — their pages are placeholder stubs (see
  each page), not real documentation.
- There is no per-domain "policy" + "strategy" pair under each of
  Safety / Security / Quality / ASPICE, as the sketch showed. Real
  policy statements live in one shared place (``governance/policies/``
  — safety, quality, and cybersecurity only; there is no ASPICE-specific
  or system-lifecycle-specific policy document), now linked as its own
  "Policies" toctree caption under :doc:`governance/index`. There is no
  per-domain "strategy" file either; the closest real analog per domain
  is that domain's ``process_description``.
- ``governance/`` has two sections beyond the sketch's four
  (Safety/Security/Quality/ASPICE) plus System Lifecycle: "Framework"
  (the enterprise process/lifecycle-model diagrams) and the "Policies"
  section just mentioned above.
- ``governance/coding guidelines/`` is deliberately not linked anywhere
  in this toctree — it's plain Markdown and this project has no
  Markdown parser registered (would need ``myst_parser`` or similar;
  out of scope for this change).
- "Strategy" appears here as its own sibling entry (matching this
  repo's real top-level folder), rather than being folded inside
  "governance and compliance" as the sketch implied.
