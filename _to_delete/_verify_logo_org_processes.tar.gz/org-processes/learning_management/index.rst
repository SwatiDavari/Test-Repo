Learning Management
=======================

**Placeholder — no content yet.** This folder exists as a scaffold (per
``scripts/sync_org_content.sh`` in test_repo, which already syncs it) but
currently holds no ``.rst`` files. Added 2026-08-21 only so "Learning
System" has a landing page and shows up as a real, working sidebar entry
rather than a broken link, while the folder is empty.
