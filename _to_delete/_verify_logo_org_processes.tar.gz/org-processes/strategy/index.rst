Enterprise Strategy
=======================

Organization-level strategic direction for the engineering platform —
vision, business objectives, and the platform/technology roadmap that
``governance/`` and ``tools/`` requirements exist to support.

**2026-08-21: converted to a real toctree** (was prose links — see
``governance/index.rst``'s note on the same, now-obsolete Furo
workaround).

.. toctree::

   strategy
   roadmap
