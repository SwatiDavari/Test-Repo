Product / Program
=====================

Product- and program-level content for this repo: published docs,
project management records, architecture, product verification/testing,
per-language source scaffolding, and this repo's own traceability needs
(``org_req``/``risk``/``problem``/``change``/``exception``/``tool``/
``infra``/``decision`` — see ``needs_types_definition.rst``). Added
2026-08-21 to collapse what used to be separate top-level sidebar
entries (``management``, a broken ``integration test`` reference) into
one "Product / Program" entry with everything nested underneath as
collapsible sub-menus, the same pattern used for "Organization".

.. toctree::
   :maxdepth: 2

   /doc/index
   /management/index
   /architecture/index
   /testing/index
   /source/index
   /needs_types_definition
   Needs <needs_redirect>

.. note::
   **Known divergences, disclosed rather than hidden:**

   - "Needs" above is a plain link into the ``needs/`` project's own
     built site, not a nested tree in *this* sidebar. ``needs/`` is a
     separate Sphinx project (own ``conf.py``, own independently
     ``-W``-gated CI build) — its left sidebar is generated from its own
     toctree and can't literally share nesting with this one without
     merging the two builds into one, which was deliberately not done
     here.
   - "Testing" here is this repo's own top-level ``testing/`` folder
     (test cases, executions, reports, strategy, suites for this
     product) — distinct from ``organisation/testing/`` (the
     organization-level ISO 29119 process, under "Organization") and
     from the previous, now-removed ``integration test/index`` toctree
     entry (that folder no longer exists on disk; still tracked as
     deleted in git, unresolved — see the separate flag on this).
   - "Docs" is ``doc/`` — release notes and errata. The product/safety
     user manuals originally sketched here moved to ``needs/user_guide/``
     instead (see that page for why) and are reachable from the root
     "User Guide" entry, not from here.
