Product / Program
=====================

Product- and program-level content for this repo: published docs,
project management records, architecture, product verification/testing,
per-language source scaffolding, and this repo's own traceability needs
(``org_req``/``risk``/``problem``/``change``/``exception``/``tool``/
``infra``/``decision`` — see ``needs_types_definition.rst``). Added
2026-08-21 to collapse what used to be separate top-level sidebar
entries (``management``, a broken ``integration test`` reference) into
one "Product / Program" entry with everything nested underneath as
collapsible sub-menus, the same pattern used for "Organization".

See :doc:`known_gaps` for divergences between this structure and the
request it was built from.

.. toctree::
   :maxdepth: 2

   /doc/index
   /management/index
   /architecture/index
   /testing/index
   /source/index
   /needs_types_definition
   Needs <needs_redirect>
   known_gaps
