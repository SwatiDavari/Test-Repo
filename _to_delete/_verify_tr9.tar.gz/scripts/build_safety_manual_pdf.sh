#!/bin/bash
# scripts/build_safety_manual_pdf.sh
#
# Build the Qorix-branded Safety User Manual PDF from
# needs/communication/safety_user_manual.rst via Sphinx's own LaTeX builder
# (required -- Sphinx-Needs directives like .. safefeat:: are NOT understood
# by plain Pandoc, which silently drops their content).
#
# Kept in scripts/ alongside build_needs.sh and fetch_external_needs.sh
# rather than at repo root -- .github/workflows/safety_user_manual_pdf.yml
# has been updated to call it here (see that file's "paths" triggers and
# its "run: bash ./scripts/build_safety_manual_pdf.sh" step).
#
# KNOWN GAP, not fixed by this change: needs/conf.py's latex_documents entry
# for this manual points at needs/communication/safety_user_manual.rst,
# which does not exist in this repo today. The only real safety-manual
# content currently lives at doc/manuals/safety/safety_user_manual.rst, in
# the root Sphinx project -- a different project entirely. Until one of
# those is reconciled (either author needs/communication/safety_user_manual.rst,
# or repoint conf.py/this pipeline at the root project's manual), running
# this script -- and the safety_user_manual_pdf.yml CI job that calls it --
# will fail at the sphinx-build step below.
#
# Run from anywhere (repo root, scripts/, or invoked directly) -- resolves
# needs/ relative to this script's own location, not the caller's cwd.
# Produces needs/_build/latex/qorix_module_a_safety_user_manual.pdf
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}/needs"

rm -rf _build/latex
sphinx-build -b latex . _build/latex

cd _build/latex

# Sphinx's sphinxhowto/sphinxmanual classes hard-code \pagestyle{plain}
# before the TOC and \pagestyle{normal} right after it, unconditionally
# overriding the fancyhdr header/footer set up in conf.py's
# latex_elements['preamble']. Force both to the fancy style directly in
# the generated .tex (macro-level \let redefinition via \AtBeginDocument
# does not reliably win against Sphinx's later explicit \pagestyle calls).
sed -i \
  -e 's/\\pagestyle{plain}/\\pagestyle{fancy}/g' \
  -e 's/\\pagestyle{normal}/\\pagestyle{fancy}/g' \
  qorix_module_a_safety_user_manual.tex

xelatex -interaction=nonstopmode qorix_module_a_safety_user_manual.tex
xelatex -interaction=nonstopmode qorix_module_a_safety_user_manual.tex

echo "Built _build/latex/qorix_module_a_safety_user_manual.pdf"
