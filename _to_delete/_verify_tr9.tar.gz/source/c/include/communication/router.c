#include "example.h"

int example_add(int a, int b) {
    return a + b;
}
